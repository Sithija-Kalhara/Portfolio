# Sithija Kalhara — Portfolio

A cinematic, dark-themed personal portfolio built with **Next.js 14 (App Router)**, **TypeScript**, **Tailwind CSS**, **Framer Motion**, and **React Three Fiber** (Three.js).

## ✨ What's inside

- **Hero** — animated rotating-role typewriter, magnetic CTA buttons, and a live interactive 3D particle sphere (React Three Fiber) that responds to mouse movement.
- **About** — bio, mission statement, animated stat cards.
- **Tech Stack** — filterable, glow-on-hover skill grid grouped by Frontend / Backend & DB / Tools & Cloud, each with an animated proficiency meter.
- **Focus Areas** — Eyerone, real-time systems, AI/data, creative media — in a bordered dashboard grid.
- **On Air (Streaming)** — a broadcast-console styled section for the "Mr. Flexy" YouTube/streaming brand, with a live-style preview panel.
- **Contact** — glassmorphism contact form + direct links to GitHub, LinkedIn, YouTube, Facebook, WhatsApp, and Email.
- Scroll-progress bar, scroll-reveal animations throughout, film-grain + vignette atmosphere, custom scrollbar, full mobile/tablet/desktop responsiveness, and `prefers-reduced-motion` support.

## 🚀 Getting started

Requires **Node.js 18.18+** (Node 20 LTS recommended).

```bash
npm install
npm run dev
```

Open [http://localhost:3000](http://localhost:3000).

### Production build

```bash
npm run build
npm run start
```

## 🗂 Project structure

```
src/
├── app/
│   ├── layout.tsx          # Root layout, fonts, SEO metadata
│   ├── page.tsx            # Landing page composition
│   └── globals.css         # Design tokens, grain/vignette, utilities
├── components/
│   ├── sections/            # Navbar, Hero, About, TechGrid, Focus, StreamSection, Contact, Footer
│   ├── three/                # HeroScene (R3F canvas) + dynamic client wrapper
│   └── ui/                   # Reveal, MagneticButton, TypewriterRoles, SectionTag, ScrollProgress
├── data/
│   └── profile.ts            # ALL personal content lives here — edit this file to update copy
└── lib/
    └── utils.ts               # cn() class-merge helper
```

## ✏️ Customizing content

Everything personal — name, roles, bio, tech stack, social links, stats — lives in **`src/data/profile.ts`**. You shouldn't need to touch component files to update copy, links, or proficiency levels.

To wire up the contact form to a real backend, replace the `setTimeout` mock in `src/components/sections/Contact.tsx`'s `handleSubmit` with a call to your API route, or a service like Resend, Formspree, or EmailJS.

## 🎨 Design system

Defined in `tailwind.config.js`:

| Token | Value | Use |
|---|---|---|
| `void` | `#05050a` | Base background |
| `panel` | `#0d0d14` | Card/panel surfaces |
| `signal-violet` | `#7c3aed` → `#a855f7` | Primary accent (dev/engineering) |
| `signal-cyan` | `#00f0ff` | Secondary accent (signal/data) |
| `signal-crimson` | `#ff1f4f` | Live/broadcast accent (streaming) |

Fonts: **Space Grotesk** (display), **Inter** (body), **JetBrains Mono** (labels/eyebrows/HUD text) — loaded via `next/font/google`, self-hosted automatically at build time (no extra requests).

## ⚡ Performance notes

- The 3D scene is loaded via `next/dynamic` with `ssr: false` so it never blocks first paint or runs server-side.
- Particle count (2,200 + 400 ambient) is tuned for smooth 60fps on mid-range laptops and recent mobile GPUs; reduce `particleCount` in `HeroScene.tsx` further if targeting low-end devices.
- All scroll animations use `whileInView` with `viewport={{ once: true }}` so they fire once and don't re-trigger cost on scroll-back.
- Respects `prefers-reduced-motion`.

## 📦 Deployment

Ready to deploy on **Vercel** (zero config) or any Node host. Set the `metadataBase` URL in `src/app/layout.tsx` to your real domain before deploying for correct Open Graph image resolution.
